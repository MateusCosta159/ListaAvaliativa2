#include <stdio.h>

int capturarDados(int *totalIdade, int *qtdRegular, int *qtdBom);
float calcularMediaIdade(int totalIdade, int totalPessoas);
float calcularPorcentagemBom(int qtdBom, int totalPessoas);
void exibirResultados(float mediaIdade, float porBom, int qtdRegular);

int main() {
    int totalIdade = 0, totalPessoas = 0, qtdRegular = 0, qtdBom = 0;
    float mediaIdade, porBom;

    totalPessoas = capturarDados(&totalIdade, &qtdRegular, &qtdBom);
    mediaIdade = calcularMediaIdade(totalIdade, totalPessoas);
    porBom = calcularPorcentagemBom(qtdBom, totalPessoas);
    exibirResultados(mediaIdade, porBom, qtdRegular);

    return 0;
}

int capturarDados(int *totalIdade, int *qtdRegular, int *qtdBom) {
    int idade, opiniao, sair, totalPessoas = 0;

    do {
        printf("Digite sua idade: ");
        scanf("%d", &idade);

        printf("Digite sua opinião:\nÓtimo[3]\nBom[2]\nRegular[1]: ");
        scanf("%d", &opiniao);

        if (opiniao == 0) {
            sair = 0;
            break;
        }

        printf("Deseja sair? Digite [0] para sair ou [1] para continuar: ");
        scanf("%d", &sair);

        *totalIdade += idade;
        totalPessoas++;

        if (opiniao == 1) {
            (*qtdRegular)++;
        }
        if (opiniao == 2) {
            (*qtdBom)++;
        }

    } while (sair != 0);

    return totalPessoas;
}

float calcularMediaIdade(int totalIdade, int totalPessoas) {
    if (totalPessoas > 0) {
        return (float)totalIdade / totalPessoas;
    } else {
        return 0;
    }
}

float calcularPorcentagemBom(int qtdBom, int totalPessoas) {
    if (totalPessoas > 0) {
        return ((float)qtdBom / totalPessoas) * 100;
    } else {
        return 0;
    }
}

void exibirResultados(float mediaIdade, float porBom, int qtdRegular) {
    printf("A porcentagem de pessoas que acharam 'Bom' foi de %.2f%%\n", porBom);
    printf("A quantidade de pessoas que acharam 'Regular' foi %d\n", qtdRegular);
    printf("A média das idades é %.2f\n", mediaIdade);
}
