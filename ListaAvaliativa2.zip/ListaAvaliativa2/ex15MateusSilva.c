#include <stdio.h>
#include <math.h>

// Declaração das funções
int lerNumero();
double calcularPotencia(int base, int expoente);
int contarDigitos(double numero);
char desejaRepetir();

int main() {
    int num1, num2;
    char repetir;
    double elevado;

    do {
        num1 = lerNumero("primeiro");
        num2 = lerNumero("segundo");

        elevado = calcularPotencia(num1, num2);

        printf("Resultado de %d^%d é: %.0f\n", num1, num2, elevado);

        int contaDigitos = contarDigitos(elevado);
        printf("O número de dígitos do resultado é: %d\n", contaDigitos);

        repetir = desejaRepetir();
    } while (repetir == 's' || repetir == 'S');

    return 0;
}

int lerNumero(const char *ordem) {
    int numero;
    do {
        printf("Digite o %s numero inteiro (1 a 100): ", ordem);
        scanf("%d", &numero);
        if (numero < 1 || numero > 100) {
            printf("Número inválido. Digite um número no intervalo de 1 a 100.\n");
        }
    } while (numero < 1 || numero > 100);
    return numero;
}


double calcularPotencia(int base, int expoente) {
    return pow(base, expoente);
}

int contarDigitos(double numero) {
    int contaDigitos = 0;
    while (numero >= 1) {
        numero /= 10;
        contaDigitos++;
    }
    return contaDigitos;
}


char desejaRepetir() {
    char repetir;
    printf("Deseja fazer outra tentativa? (s/n): ");
    scanf(" %c", &repetir);
    return repetir;
}
