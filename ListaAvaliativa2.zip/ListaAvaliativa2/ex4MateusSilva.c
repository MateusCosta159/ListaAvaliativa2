#include <stdio.h>

double calcularTermo(double termoAnterior, int i);

int main() {
    int termos = 20;
    double soma = 0.0;
    double termoAtual = 100.0; 

   
    for (int i = 0; i < termos; ++i) {
        if (i > 0) {
            termoAtual = calcularTermo(termoAtual, i);
        }
        soma += termoAtual;
    }

    printf("A soma dos 20 primeiros termos da série é: %.10lf\n", soma);

    return 0;
}


double calcularTermo(double termoAnterior, int i) {
    return termoAnterior * (100.0 - (i - 1)) / i;
}
