#include <stdio.h>
#include <string.h>

void contaCaracterisica(int cod, int idade, int sexo, int salario, char nome[], int *contCod, int *contNome, int *contIda, int *contSexo, int *contSal);

int main() {
    int cod, idade, sexo, salario, funcionarios = 1;
    int contCod = 0, contIda = 0, contSexo = 0, contSal = 0, contNome = 0;
    char nome[50];

    while (funcionarios <= 2) {
        printf("Digite seu nome: ");
        scanf("%s", nome);

        printf("Digite seu codigo: ");
        scanf("%d", &cod);

        printf("Digite sua idade: ");
        scanf("%d", &idade);

        printf("Digite seu sexo Feminino[1] Masculino[2]: ");
        scanf("%d", &sexo);

        printf("Digite seu salario: ");
        scanf("%d", &salario);

        contaCaracterisica(cod, idade, sexo, salario, nome, &contCod, &contNome, &contIda, &contSexo, &contSal);
      
        funcionarios++;
    }

    printf("A quantidade de funcionarios com codigo menor que 100: %d\n", contCod);
    printf("A quantidade de funcionarios chamado Jose: %d\n", contNome);
    printf("A quantidade de funcionarios com idade superior a 60: %d\n", contIda);
    printf("A quantidade de funcionarias do sexo feminino: %d\n", contSexo);
    printf("A quantidade de funcionarios com salario entre 1000 e 2000: %d\n", contSal);

    return 0;
}
void contaCaracterisica(int cod, int idade, int sexo, int salario, char nome[], int *contCod, int *contNome, int *contIda, int *contSexo, int *contSal) {
    if (cod < 100) {
        (*contCod)++;
    }
    if (strcmp(nome, "Jose") == 0) {
        (*contNome)++;
    }
    if (idade > 60) {
        (*contIda)++;
    }
    if (sexo == 1) {
        (*contSexo)++;
    }
    if (salario >= 1000 && salario <= 2000) {
        (*contSal)++;
    }
}