#include <stdio.h>

float obterMenorTempo(int T);

int main() {
    int T1, T2;
    float menorTempo1, menorTempo2;

    do {
        printf("Digite a quantidade de tentativas da primeira bateria (minimo 2, 0 para sair): ");
        scanf("%d", &T1);

        if (T1 == 0) {
            return 0;
        }

        if (T1 < 2 || T1 > 99) {
            printf("Numero de tentativas fora dos limites permitidos. Tente novamente.\n");
        }
    } while (T1 < 2 || T1 > 99);

    menorTempo1 = obterMenorTempo(T1);

    do {
        printf("Digite a quantidade de tentativas da segunda bateria (minimo 2, 0 para sair): ");
        scanf("%d", &T2);

        if (T2 == 0) {
            return 0;
        }

        if (T2 < 2 || T2 > 99) {
            printf("Numero de tentativas fora dos limites permitidos. Tente novamente.\n");
        }
    } while (T2 < 2 || T2 > 99);

    menorTempo2 = obterMenorTempo(T2);

    printf("Menor tempo da primeira bateria: %.2f segundos\n", menorTempo1);
    printf("Menor tempo da segunda bateria: %.2f segundos\n", menorTempo2);

    if (menorTempo1 < menorTempo2) {
        printf("O menor tempo foi da primeira bateria: %.2f segundos\n", menorTempo1);
    } else if (menorTempo2 < menorTempo1) {
        printf("O menor tempo foi da segunda bateria: %.2f segundos\n", menorTempo2);
    } else {
        printf("Ambas as baterias tiveram o mesmo menor tempo: %.2f segundos\n", menorTempo1);
    }

    return 0;
}

float obterMenorTempo(int T) {
    float tempo, menorTempo;

    do {
        printf("Digite o tempo da tentativa 1 (entre 9 e 11 segundos): ");
        scanf("%f", &tempo);

        if (tempo < 9 || tempo > 11) {
            printf("Tempo fora dos limites permitidos. Tente novamente.\n");
        }
    } while (tempo < 9 || tempo > 11);

    menorTempo = tempo;

    for (int i = 1; i < T; i++) {
        do {
            printf("Digite o tempo da tentativa %d (entre 9 e 11 segundos): ", i + 1);
            scanf("%f", &tempo);

            if (tempo < 9 || tempo > 11) {
                printf("Tempo fora dos limites permitidos. Tente novamente.\n");
            }
        } while (tempo < 9 || tempo > 11);

        if (tempo < menorTempo) {
            menorTempo = tempo;
        }
    }

    return menorTempo;
}
