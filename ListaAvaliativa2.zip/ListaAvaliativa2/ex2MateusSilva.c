#include <stdio.h>

void gerarFetuccine(int n, int a, int b);

int main() {
    int n, a, b;

    printf("Digite o número de termos da série (pelo menos 3): ");
    scanf("%d", &n);

    if (n < 3) {
        printf("A série de Fetuccine requer pelo menos 3 termos.\n");
        return 1;
    }

    printf("Digite o primeiro termo da série: ");
    scanf("%d", &a);
    printf("Digite o segundo termo da série: ");
    scanf("%d", &b);

    gerarFetuccine(n, a, b);

    return 0;
}

void gerarFetuccine(int n, int a, int b) {
    int anterior = a, atual = b, proximo;

    printf("Série Fetuccine: %d %d ", anterior, atual);

    for (int i = 2; i < n; i++) {
        if (i % 2 == 0) {
            proximo = anterior - atual;
        } else {
            proximo = anterior + atual;
        }
        
        printf("%d ", proximo);

        anterior = atual;
        atual = proximo;
    }
    printf("\n");
}
