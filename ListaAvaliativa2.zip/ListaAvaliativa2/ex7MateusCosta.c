#include <stdio.h>

int calcularIdadeMeses(int anos);
int calcularIdadeDias(int anos);

int main() {
    int idade, idadeMeses, idadeDias;

    do {
        
        printf("Digite sua idade em ANOS (digite um valor negativo para sair): ");
        scanf("%d", &idade);

        
        if (idade < 0) {
            break;
        }

        idadeMeses = calcularIdadeMeses(idade);
        idadeDias = calcularIdadeDias(idade);

        // Mostra a idade em meses e dias
        printf("Sua idade em meses: %d\n", idadeMeses);
        printf("Sua idade em dias: %d\n", idadeDias);

    } while (idade >= 0);

    printf("Programa encerrado.\n");

    return 0;
}
int calcularIdadeMeses(int anos) {
    return anos * 12;
}


int calcularIdadeDias(int anos) {
    return anos * 365;
}