#include <stdio.h>

void Pontos(int distancia);

int main() {
    int distancia;

   
    do {
        printf("Digite a distância do robô para a cesta (0 a 2000 cm): ");
        scanf("%d", &distancia);

        if (distancia < 0 || distancia > 2000) {
            printf("Distância inválida. A distância deve estar entre 0 e 2000 cm.\n");
        }
    } while (distancia < 0 || distancia > 2000);

    
    Pontos(distancia);    

    return 0;
}
void Pontos(int distancia){
    if (distancia <= 800) {
        printf("O robô fez uma cesta de 1 pontos, lançando de uma distância de %d cm\n", distancia);
    } else if (distancia <= 1400) {
        printf("O robô fez uma cesta de 2 pontos, lançando de uma distância de %d cm\n", distancia);
    } else {
        printf("O robô fez uma cesta de 3 ponto, lançando de uma distância de %d cm\n", distancia);
    }
}