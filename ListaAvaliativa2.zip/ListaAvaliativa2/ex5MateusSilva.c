#include <stdio.h>
float calcularTempoNecessario(float massa);

int main() {
    float massa, tempo;

    printf("Digite a massa do material radioativo analisado em gramas: ");
    scanf("%f", &massa);

 
    tempo = calcularTempoNecessario(massa);

    printf("O tempo necessário foi de %.2f segundos\n", tempo);

    return 0;
}


float calcularTempoNecessario(float massa) {
    float tempo = 0.0;

    while (massa >= 0.10) {
        massa *= 0.75;
        tempo += 30;
    }

    return tempo;
}
