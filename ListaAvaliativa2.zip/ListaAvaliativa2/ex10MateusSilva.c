#include <stdio.h>
int calcularFatorial(int n);

int main() {
    int numero;

  
    do {
        printf("Digite um número inteiro positivo: ");
        scanf("%d", &numero);

        if (numero < 0) {
            printf("Número inválido. Por favor, insira um número inteiro positivo.\n");
        }
    } while (numero < 0);

  
    int fatorial = calcularFatorial(numero);


    printf("O fatorial de %d é: %d\n", numero, fatorial);

    return 0;
}


int calcularFatorial(int n) {
    int fatorial = 1;
    for (int i = 1; i <= n; i++) {
        fatorial *= i;
    }
    return fatorial;
}
