#include <stdio.h>


float calcularTotal(float preco, int quantidade);
void processarPagamento(float total);

int main() {
    char novoPedido;

    do {
       
        float precoCoxinha = 8.50;
        float precoEnrolado = 8.50;
        float precoBola1 = 8.80;
        float precoBola2 = 8.80;
        float precoBola3 = 12.00;
        float precoBola4 = 11.50;
        float precoAgua = 4.00;
        float precoAguaComGas = 4.50;
        float precoRefrigerante = 7.00;
        float precoSuco = 7.50;
        float precoCerveja = 8.00;

        int quantidadeCoxinha, quantidadeEnrolado, quantidadeBola1, quantidadeBola2, quantidadeBola3, quantidadeBola4;
        int quantidadeAgua, quantidadeAguaComGas, quantidadeRefrigerante, quantidadeSuco, quantidadeCerveja;

        printf("Quantas coxinhas (frango)? ");
        scanf("%d", &quantidadeCoxinha);
        printf("Quantos enrolados (presunto e queijo)? ");
        scanf("%d", &quantidadeEnrolado);
        printf("Quantas bolas1 (frango e catupiry)? ");
        scanf("%d", &quantidadeBola1);
        printf("Quantas bolas2 (brócolis e catupiry)? ");
        scanf("%d", &quantidadeBola2);
        printf("Quantas bolas3 (camarão)? ");
        scanf("%d", &quantidadeBola3);
        printf("Quantas bolas4 (queijo e catupiry)? ");
        scanf("%d", &quantidadeBola4);
        printf("Quantas águas? ");
        scanf("%d", &quantidadeAgua);
        printf("Quantas águas com gás? ");
        scanf("%d", &quantidadeAguaComGas);
        printf("Quantos refrigerantes? ");
        scanf("%d", &quantidadeRefrigerante);
        printf("Quantos sucos (lata)? ");
        scanf("%d", &quantidadeSuco);
        printf("Quantas cervejas? ");
        scanf("%d", &quantidadeCerveja);

        float totalSalgados = calcularTotal(precoCoxinha, quantidadeCoxinha) + 
                              calcularTotal(precoEnrolado, quantidadeEnrolado) + 
                              calcularTotal(precoBola1, quantidadeBola1) + 
                              calcularTotal(precoBola2, quantidadeBola2) + 
                              calcularTotal(precoBola3, quantidadeBola3) + 
                              calcularTotal(precoBola4, quantidadeBola4);

        float totalBebidas = calcularTotal(precoAgua, quantidadeAgua) + 
                             calcularTotal(precoAguaComGas, quantidadeAguaComGas) + 
                             calcularTotal(precoRefrigerante, quantidadeRefrigerante) + 
                             calcularTotal(precoSuco, quantidadeSuco) + 
                             calcularTotal(precoCerveja, quantidadeCerveja);

        float total = totalSalgados + totalBebidas;

        printf("\nTotal dos salgados: R$ %.2f\n", totalSalgados);
        printf("Total das bebidas: R$ %.2f\n", totalBebidas);
        printf("Total geral: R$ %.2f\n", total);

   
        processarPagamento(total);

      
        printf("\nDeseja fazer um novo pedido? (s/n): ");
        scanf(" %c", &novoPedido);

    } while (novoPedido == 's' || novoPedido == 'S');

    return 0;
}


float calcularTotal(float preco, int quantidade) {
    return preco * quantidade;
}

void processarPagamento(float total) {
    int formaPagamento;
    float valorPago, troco;

    printf("\nFormas de pagamento:\n");
    printf("1 - Dinheiro\n");
    printf("2 - Cartão de crédito\n");
    printf("3 - Cartão de débito\n");
    printf("Escolha a forma de pagamento: ");
    scanf("%d", &formaPagamento);

    if (formaPagamento == 1) {
        printf("Digite o valor entregue: ");
        scanf("%f", &valorPago);

        if (valorPago >= total) {
            troco = valorPago - total;
            printf("Troco: R$ %.2f\n", troco);
        } else {
            printf("Valor insuficiente!\n");
        }
    } else if (formaPagamento == 2 || formaPagamento == 3) {
        printf("Pagamento realizado com sucesso!\n");
    } else {
        printf("Forma de pagamento inválida!\n");
    }
}
