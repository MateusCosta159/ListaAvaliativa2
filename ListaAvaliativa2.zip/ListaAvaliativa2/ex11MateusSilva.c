#include <stdio.h>

void coletarDados(int *idCidade, int *veiculosPasseio, int *acVitimas, int *acSemVitimas);
void atualizarSomaVeiculos(int veiculosPasseio, int *somaVeiculos);
void verificarMenos5000(int veiculosPasseio, int acVitimas, int acSemVitimas, int *somaAcidentesMenos5000, int *cidadesMenos5000);
void verificarIndices(int idCidade, int acVitimas, int *maiorIndice, int *cidadeMaior, int *menorIndice, int *cidadeMenor);
int calcularMediaVeiculos(int somaVeiculos);


int main() {
    int idCidade, veiculosPasseio, acVitimas, acSemVitimas;
    int maiorIndice = -1, menorIndice = 1000000;
    int cidadeMaior, cidadeMenor;
    int somaVeiculos = 0, somaAcidentesMenos5000 = 0, cidadesMenos5000 = 0;

    for (int i = 1; i <= 5; i++) {
        coletarDados(&idCidade, &veiculosPasseio, &acVitimas, &acSemVitimas);

        atualizarSomaVeiculos(veiculosPasseio, &somaVeiculos);
        verificarMenos5000(veiculosPasseio, acVitimas, acSemVitimas, &somaAcidentesMenos5000, &cidadesMenos5000);
        verificarIndices(idCidade, acVitimas, &maiorIndice, &cidadeMaior, &menorIndice, &cidadeMenor);
    }

    int mediaVeiculos = calcularMediaVeiculos(somaVeiculos);

        float mediaAcidentesMenos5000 = 0.0;
    if (cidadesMenos5000 > 0) {
        mediaAcidentesMenos5000 = (float)somaAcidentesMenos5000 / cidadesMenos5000;
    }

    printf("\nResultado da pesquisa:\n");
    printf("Maior índice de acidentes com vítimas: %d (Cidade %d)\n", maiorIndice, cidadeMaior);
    printf("Menor índice de acidentes com vítimas: %d (Cidade %d)\n", menorIndice, cidadeMenor);
    printf("Média de veículos nas cinco cidades: %d\n", mediaVeiculos);
    if (cidadesMenos5000 > 0) {
        printf("Média de acidentes nas cidades com menos de 5000 veículos: %.2f\n", mediaAcidentesMenos5000);
    } else {
        printf("Nenhuma cidade com menos de 5000 veículos foi encontrada.\n");
    }

    return 0;
}


void coletarDados(int *idCidade, int *veiculosPasseio, int *acVitimas, int *acSemVitimas) {
    printf("Digite o Código da cidade: De 1 a 5: ");
    scanf("%d", idCidade);
    printf("Numero de Veiculos de Passeio: ");
    scanf("%d", veiculosPasseio);
    printf("Numero de acidentes sem vitimas: ");
    scanf("%d", acSemVitimas);
    printf("Numero de acidentes com vitimas: ");
    scanf("%d", acVitimas);
}


void atualizarSomaVeiculos(int veiculosPasseio, int *somaVeiculos) {
    *somaVeiculos += veiculosPasseio;
}


void verificarMenos5000(int veiculosPasseio, int acVitimas, int acSemVitimas, int *somaAcidentesMenos5000, int *cidadesMenos5000) {
    if (veiculosPasseio < 5000) {
        *somaAcidentesMenos5000 += (acVitimas + acSemVitimas);
        (*cidadesMenos5000)++;
    }
}


void verificarIndices(int idCidade, int acVitimas, int *maiorIndice, int *cidadeMaior, int *menorIndice, int *cidadeMenor) {
    if (acVitimas > *maiorIndice) {
        *maiorIndice = acVitimas;
        *cidadeMaior = idCidade;
    }
    if (acVitimas < *menorIndice) {
        *menorIndice = acVitimas;
        *cidadeMenor = idCidade;
    }
}


int calcularMediaVeiculos(int somaVeiculos) {
    return somaVeiculos / 5;
}

