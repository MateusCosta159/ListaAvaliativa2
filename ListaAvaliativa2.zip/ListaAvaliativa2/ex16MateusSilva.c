#include <stdio.h>

void mostrarTabuleiro(char c1, char c2, char c3, char c4, char c5, char c6, char c7, char c8, char c9);
int verificarVencedor(char c1, char c2, char c3, char c4, char c5, char c6, char c7, char c8, char c9, char jogador);
void jogarJogoDaVelha();

int main() {
    jogarJogoDaVelha();
    return 0;
}


void mostrarTabuleiro(char c1, char c2, char c3, char c4, char c5, char c6, char c7, char c8, char c9) {
    printf("\n");
    printf(" %c | %c | %c \n", c1, c2, c3);
    printf("---|---|---\n");
    printf(" %c | %c | %c \n", c4, c5, c6);
    printf("---|---|---\n");
    printf(" %c | %c | %c \n", c7, c8, c9);
    printf("\n");
}

int verificarVencedor(char c1, char c2, char c3, char c4, char c5, char c6, char c7, char c8, char c9, char jogador) {
  
    if ((c1 == jogador && c2 == jogador && c3 == jogador) ||
        (c4 == jogador && c5 == jogador && c6 == jogador) ||
        (c7 == jogador && c8 == jogador && c9 == jogador)) {
        return 1;
    }

    if ((c1 == jogador && c4 == jogador && c7 == jogador) ||
        (c2 == jogador && c5 == jogador && c8 == jogador) ||
        (c3 == jogador && c6 == jogador && c9 == jogador)) {
        return 1;
    }

   
    if ((c1 == jogador && c5 == jogador && c9 == jogador) ||
        (c3 == jogador && c5 == jogador && c7 == jogador)) {
        return 1;
    }

    return 0;
}

void jogarJogoDaVelha() {
    const int TAM = 3; 
    char c1 = ' ', c2 = ' ', c3 = ' ';
    char c4 = ' ', c5 = ' ', c6 = ' ';
    char c7 = ' ', c8 = ' ', c9 = ' ';
    char jogadorAtual = 'X';
    int posicao;
    int jogadas = 0;
    int totalJogadas = TAM * TAM;
    int vencedor = 0;

    while (jogadas < totalJogadas && vencedor == 0) {
        mostrarTabuleiro(c1, c2, c3, c4, c5, c6, c7, c8, c9);
        printf("Jogador %c, escolha uma posição (1-9): ", jogadorAtual);
        scanf("%d", &posicao);

        if (posicao >= 1 && posicao <= 9) {
            if (posicao == 1 && c1 == ' ') c1 = jogadorAtual;
            else if (posicao == 2 && c2 == ' ') c2 = jogadorAtual;
            else if (posicao == 3 && c3 == ' ') c3 = jogadorAtual;
            else if (posicao == 4 && c4 == ' ') c4 = jogadorAtual;
            else if (posicao == 5 && c5 == ' ') c5 = jogadorAtual;
            else if (posicao == 6 && c6 == ' ') c6 = jogadorAtual;
            else if (posicao == 7 && c7 == ' ') c7 = jogadorAtual;
            else if (posicao == 8 && c8 == ' ') c8 = jogadorAtual;
            else if (posicao == 9 && c9 == ' ') c9 = jogadorAtual;
            else {
                printf("Posição inválida ou já ocupada. Tente novamente.\n");
                continue;
            }

            jogadas++;


            if (verificarVencedor(c1, c2, c3, c4, c5, c6, c7, c8, c9, jogadorAtual)) {
                vencedor = jogadorAtual;
            } else {
                jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
            }
        } else {
            printf("Entrada inválida. Tente novamente.\n");
        }
    }

    mostrarTabuleiro(c1, c2, c3, c4, c5, c6, c7, c8, c9);

    if (vencedor != 0) {
        printf("Jogador %c venceu!\n", vencedor);
    } else {
        printf("Empate!\n");
    }
}
