#include <stdio.h>

void verificaTime(int escolha, int *timeA, int *timeB, int *timeC, int *somaIdadeA, int *somaIdadeB, int *somaIdadeC, int idade);
void entradaDados(int *idade, float *altura, float *peso, int *escolha);
void calculaMedias(int somaIdadeA, int somaIdadeB, int somaIdadeC, int timeA, int timeB, int timeC, int somaPeso, int qtdParticipantes, int qtdMais45kg, int qtdMenor15);

int main() {
    int timeA = 0, timeB = 0, timeC = 0, qtdParticipantes = 0;
    int idade, escolha, qtdMenor15 = 0;
    float altura, peso;
    int somaIdadeA = 0, somaIdadeB = 0, somaIdadeC = 0, somaPeso = 0, qtdMais45kg = 0;

    while (qtdParticipantes < 18) {
        entradaDados(&idade, &altura, &peso, &escolha);

        if (idade <= 8 || idade >= 15) {
            printf("Idade inválida. Deve estar entre 9 e 14 anos.\n");
            continue;
        }

        verificaTime(escolha, &timeA, &timeB, &timeC, &somaIdadeA, &somaIdadeB, &somaIdadeC, idade);

        qtdParticipantes++;
        somaPeso += peso;

        if (idade < 15) {
            qtdMenor15++;
        }

        if (peso > 45) {
            qtdMais45kg++;
        }

        printf("Você foi inscrito na competição.\n");
    }

    calculaMedias(somaIdadeA, somaIdadeB, somaIdadeC, timeA, timeB, timeC, somaPeso, qtdParticipantes, qtdMais45kg, qtdMenor15);

    return 0;
}

void verificaTime(int escolha, int *timeA, int *timeB, int *timeC, int *somaIdadeA, int *somaIdadeB, int *somaIdadeC, int idade){
    if (escolha == 1 && *timeA < 6) {
        (*timeA)++;
        (*somaIdadeA) += idade;
    } else if (escolha == 2 && *timeB < 6) {
        (*timeB)++;
        (*somaIdadeB) += idade;
    } else if (escolha == 3 && *timeC < 6) {
        (*timeC)++;
        (*somaIdadeC) += idade;
    } else {
        printf("O time escolhido não suporta mais jogadores, escolha outro.\n");
    }
}

void entradaDados(int *idade, float *altura, float *peso, int *escolha) {
    printf("Digite sua idade (menor de 15 anos e maior que 8): ");
    scanf("%d", idade);

    printf("Digite sua altura: ");
    scanf("%f", altura);

    printf("Digite seu peso: ");
    scanf("%f", peso);

    printf("Digite número conforme for seu time: Time A[1], Time B[2], Time C[3]: ");
    scanf("%d", escolha);
}

void calculaMedias(int somaIdadeA, int somaIdadeB, int somaIdadeC, int timeA, int timeB, int timeC, int somaPeso, int qtdParticipantes, int qtdMais45kg, int qtdMenor15) {

    float mediaIdadeA,mediaIdadeB,mediaIdadeC, mediaPeso, percentagemMais45kg;
    
    
     mediaIdadeA = (timeA > 0) ? (float)somaIdadeA / timeA : 0;
     mediaIdadeB = (timeB > 0) ? (float)somaIdadeB / timeB : 0;
     mediaIdadeC = (timeC > 0) ? (float)somaIdadeC / timeC : 0;
     mediaPeso = (float)somaPeso / qtdParticipantes;
     percentagemMais45kg = ((float)qtdMais45kg / qtdParticipantes) * 100;

    printf("\nQuantidade de jogadores com idade inferior a 15 anos: %d\n", qtdMenor15);
    printf("Média de idade do time A: %.2f\n", mediaIdadeA);
    printf("Média de idade do time B: %.2f\n", mediaIdadeB);
    printf("Média de idade do time C: %.2f\n", mediaIdadeC);
    printf("Média do peso dos jogadores do campeonato: %.2f kg\n", mediaPeso);
    printf("Percentagem de jogadores com mais de 45 quilos: %.2f%%\n", percentagemMais45kg);
}
