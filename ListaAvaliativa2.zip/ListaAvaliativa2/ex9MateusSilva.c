#include <stdio.h>
#include <math.h>

int main() {
    int num1 = 2, num2 = 50, i;
    double result, somaResult = 0;

   
    for (i = 1; i <= 50; i++) {
        result = pow(num1, i);
        result = result / num2;
        printf("S = %d^%d / %d = %f\n", num1, i, num2, result);
        
        somaResult += result;
        num2--;
    }

    printf("Soma da primeira série: %f\n", somaResult);

    int aux1 = 1;
    num2 = 1;
    float resultFinal = 0;
    int sinal = 1;  

    for (i = 1; i <= 10; i++) {
        int aux = pow(num2, 2);
        result = (float)aux1 / aux * sinal;
        printf("%d / %d = %.2f \n", aux1, aux, result);

        resultFinal += result;
        sinal *= -1;  
        aux1++;
        num2++;
    }

    printf("Soma da segunda série: %.2f\n", resultFinal);

    return 0;
}
