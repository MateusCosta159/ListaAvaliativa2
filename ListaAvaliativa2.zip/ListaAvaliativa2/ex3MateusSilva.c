#include <stdio.h>

// Funções declaradas fora do main
char elevadorMaisFrequentado(int A, int B, int C);
char periodoMaisFluxo(int M, int V, int N);
float diferencaPercentual(int maisUsado, int menosUsado);

int main() {
    int moradores = 1;
    char elevador, periodo;
    int A = 0, B = 0, C = 0, M = 0, V = 0, N = 0;
    int AM = 0, AV = 0, AN = 0, BM = 0, BV = 0, BN = 0, CM = 0, CV = 0, CN = 0;

    while (moradores <= 50) {
        printf("Digite o numero referente ao elevador que voce mais utiliza [A, B ou C]: ");
        scanf(" %c", &elevador);

        printf("Digite o periodo que mais usa o elevador [M (Manha), V (Tarde), N (Noite)]: ");
        scanf(" %c", &periodo);

        if(elevador == 'A' || elevador == 'a') {
            A++;
            if(periodo == 'M' || periodo == 'm') {
                M++;
                AM++;
            } else if(periodo == 'V' || periodo == 'v') {
                V++;
                AV++;
            } else if(periodo == 'N' || periodo == 'n') {
                N++;
                AN++;
            } else {
                printf("Valor digitado para o periodo nao e valido\n");
            }
        } else if(elevador == 'B' || elevador == 'b') {
            B++;
            if(periodo == 'M' || periodo == 'm') {
                M++;
                BM++;
            } else if(periodo == 'V' || periodo == 'v') {
                V++;
                BV++;
            } else if(periodo == 'N' || periodo == 'n') {
                N++;
                BN++;
            } else {
                printf("Valor digitado para o periodo nao e valido\n");
            }
        } else if(elevador == 'C' || elevador == 'c') {
            C++;
            if(periodo == 'M' || periodo == 'm') {
                M++;
                CM++;
            } else if(periodo == 'V' || periodo == 'v') {
                V++;
                CV++;
            } else if(periodo == 'N' || periodo == 'n') {
                N++;
                CN++;
            } else {
                printf("Valor digitado para o periodo nao e valido\n");
            }
        } else {
            printf("Valor digitado para o elevador nao corresponde\n");
        }
        moradores++;
    }

    
    char mais_frequentado = elevadorMaisFrequentado(A, B, C);
    char maior_fluxo = periodoMaisFluxo(M, V, N);
    
    char periodo_mais_usado = maior_fluxo;
    char elevador_mais_usado_no_periodo;
    if (periodo_mais_usado == 'M') {
        if (AM >= BM && AM >= CM) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (BM >= CM) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    } else if (periodo_mais_usado == 'V') {
        if (AV >= BV && AV >= CV) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (BV >= CV) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    } else {
        if (AN >= BN && AN >= CN) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (BN >= CN) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    }

    
    if (periodo_mais_usado == 'M') {
        if (A >= B && A >= C) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (B >= C) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    } else if (periodo_mais_usado == 'V') {
        if (A >= B && A >= C) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (B >= C) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    } else {
        if (A >= B && A >= C) {
            elevador_mais_usado_no_periodo = 'A';
        } else if (B >= C) {
            elevador_mais_usado_no_periodo = 'B';
        } else {
            elevador_mais_usado_no_periodo = 'C';
        }
    }

   
    int mais_usado, menos_usado;

    if (A >= B && A >= C) {
        mais_usado = A;
    } else if (B >= C) {
        mais_usado = B;
    } else {
        mais_usado = C;
    }

    if (A <= B && A <= C) {
        menos_usado = A;
    } else if (B <= C) {
        menos_usado = B;
    } else {
        menos_usado = C;
    }

    float diferenca_percentual = diferencaPercentual(mais_usado, menos_usado);

    printf("Elevador mais frequentado: %c\n", mais_frequentado);
    printf("Periodo com maior fluxo: %c\n", maior_fluxo);
    printf("Periodo mais usado: %c pertence ao elevador: %c\n", periodo_mais_usado, elevador_mais_usado_no_periodo);
    printf("Diferenca percentual entre o mais usado e o menos usado: %.2f%%\n", diferenca_percentual);

    return 0;
}

char elevadorMaisFrequentado(int A, int B, int C) {
    if (A >= B && A >= C) {
        return 'A';
    } else if (B >= C) {
        return 'B';
    } else {
        return 'C';
    }
}

char periodoMaisFluxo(int M, int V, int N) {
    if (M >= V && M >= N) {
        return 'M';
    } else if (V >= N) {
        return 'V';
    } else {
        return 'N';
    }
}

float diferencaPercentual(int maisUsado, int menosUsado) {
    return ((maisUsado - menosUsado) / (float)maisUsado) * 100;
}
